If you get a Windows Defender warning, click "More Info" → "Run Anyway"
This is common for new or unsigned apps.
Do not worry, this is not a virus, it is your choice if you prefer to use this or not.